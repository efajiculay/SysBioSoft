"""

                       This is the __main__ module

This module calls the BioSANS function in BioSANS2020.RunBioSANS.

"""

# from subprocess import Popen
# from sys import executable
# Popen(str(executable)+" -m BioSANS2020.BioSANS")

from BioSANS2020.RunBioSANS import BioSANS
BioSANS()
