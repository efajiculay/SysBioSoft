import os
import sys

def main1():
	os.system(str(sys.executable)+" -m BioSANS2020.BioSANS")

def main2():
	os.system(str(sys.executable)+" -m BioSANS2020.BioSSL")