from scrollable_text import *

def new_file(items):	
	text = prepare_scroll_text(items)
	return text