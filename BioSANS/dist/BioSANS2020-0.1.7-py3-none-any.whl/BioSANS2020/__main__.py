#from subprocess import Popen
#from sys import executable
#Popen(str(executable)+" -m BioSANS2020.BioSANS")

from BioSANS2020.RunBioSANS import*
BioSANS()